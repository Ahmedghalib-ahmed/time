package com.studytimer.pro.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.studytimer.pro.data.local.entities.Achievements
import com.studytimer.pro.data.local.entities.Subject
import com.studytimer.pro.data.local.entities.UserProfile
import com.studytimer.pro.data.repository.FocusRepository
import com.studytimer.pro.util.XPCalculator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

// ═══════════════════════════════════════════════════════════════
//  HomeViewModel
// ═══════════════════════════════════════════════════════════════
data class HomeUiState(
    val profile          : UserProfile?  = null,
    val subjects         : List<Subject> = emptyList(),
    val minutesToday     : Int           = 0,
    val sessionsToday    : Int           = 0,
    val dailyGoal        : Int           = 120,
    val levelProgress    : Float         = 0f,
    val xpToNextLevel    : Int           = 0,
    val streak           : Int           = 0,
    val last7DayMinutes  : List<Pair<String, Int>> = emptyList(),
    val motivationalQuote: Pair<String, String>     = quotes.random(),
)

private val quotes = listOf(
    "Focus is the art of knowing what to ignore." to "James Clear",
    "The successful warrior is the average person with laser-like focus." to "Bruce Lee",
    "Where focus goes, energy flows." to "Tony Robbins",
    "Concentrate all your thoughts upon the work at hand." to "Alexander Graham Bell",
    "It's not about having time, it's about making time." to "Unknown",
    "Small disciplines repeated with consistency every day lead to great achievements." to "John Maxwell",
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: FocusRepository,
) : ViewModel() {

    private val _ui = MutableStateFlow(HomeUiState())
    val ui: StateFlow<HomeUiState> = _ui.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                repository.userProfile,
                repository.allSubjects,
                repository.minutesToday(),
                repository.sessionCountToday(),
                repository.dailySummaryLastNDays(7),
            ) { profile, subjects, minsToday, sessToday, last7 ->
                val p = profile ?: UserProfile()
                HomeUiState(
                    profile           = p,
                    subjects          = subjects,
                    minutesToday      = minsToday,
                    sessionsToday     = sessToday,
                    dailyGoal         = p.dailyGoalMinutes,
                    levelProgress     = XPCalculator.progressInLevel(p.totalXP),
                    xpToNextLevel     = XPCalculator.xpForNextLevel(p.level) - p.totalXP,
                    streak            = p.currentStreak,
                    last7DayMinutes   = last7.map { it.dateIso.takeLast(5) to it.totalMinutes },
                    motivationalQuote = quotes.random(),
                )
            }.collect { _ui.value = it }
        }
    }

    fun addSubject(name: String, emoji: String, colorHex: String) {
        viewModelScope.launch {
            repository.addSubject(Subject(name = name, emoji = emoji, colorHex = colorHex))
        }
    }

    fun setDailyGoal(minutes: Int) {
        viewModelScope.launch { repository.updateDailyGoal(minutes) }
    }
}

// ═══════════════════════════════════════════════════════════════
//  StatsViewModel
// ═══════════════════════════════════════════════════════════════
data class DayBar(val label: String, val minutes: Int)

data class StatsUiState(
    val profile       : UserProfile?     = null,
    val last7Bars     : List<DayBar>     = emptyList(),
    val totalThisWeek : Int              = 0,
    val totalThisMonth: Int              = 0,
    val topSubjects   : List<Subject>    = emptyList(),
    val achievementIds: Set<String>      = emptySet(),
    val levelProgress : Float            = 0f,
    val focusScore    : Int              = 0,      // 0-100
)

@HiltViewModel
class StatsViewModel @Inject constructor(
    private val repository: FocusRepository,
) : ViewModel() {

    private val _ui = MutableStateFlow(StatsUiState())
    val ui: StateFlow<StatsUiState> = _ui.asStateFlow()

    val allAchievements = Achievements.all

    init {
        viewModelScope.launch {
            combine(
                repository.userProfile,
                repository.allSubjects,
                repository.dailySummaryLastNDays(7),
                repository.sessionsInRange(
                    LocalDate.now().minusDays(30), LocalDate.now()
                ),
            ) { profile, subjects, last7, monthSessions ->
                val p = profile ?: UserProfile()
                val bars = last7.map { DayBar(it.dateIso.takeLast(5), it.totalMinutes) }
                val weekMins = bars.sumOf { it.minutes }
                val monthMins = monthSessions.sumOf { it.durationMinutes }
                val avgDay = if (bars.isNotEmpty()) weekMins / 7 else 0
                val score = ((avgDay.toFloat() / p.dailyGoalMinutes) * 100)
                    .toInt().coerceIn(0, 100)
                StatsUiState(
                    profile        = p,
                    last7Bars      = bars,
                    totalThisWeek  = weekMins,
                    totalThisMonth = monthMins,
                    topSubjects    = subjects.take(5),
                    achievementIds = repository.getUnlockedAchievements(p),
                    levelProgress  = XPCalculator.progressInLevel(p.totalXP),
                    focusScore     = score,
                )
            }.collect { _ui.value = it }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
//  PlannerViewModel
// ═══════════════════════════════════════════════════════════════
enum class PlannerView { DAY, WEEK, MONTH }

data class PlannerUiState(
    val selectedDate: LocalDate     = LocalDate.now(),
    val viewMode    : PlannerView   = PlannerView.DAY,
    val sessions    : List<com.studytimer.pro.data.local.entities.FocusSession> = emptyList(),
    val subjects    : List<Subject> = emptyList(),
    val showAddModal: Boolean       = false,
)

@HiltViewModel
class PlannerViewModel @Inject constructor(
    private val repository: FocusRepository,
) : ViewModel() {

    private val _ui = MutableStateFlow(PlannerUiState())
    val ui: StateFlow<PlannerUiState> = _ui.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                snapshotFlow { _ui.value.selectedDate },
                repository.allSubjects,
            ) { date, subjects -> date to subjects }
            .flatMapLatest { (date, subjects) ->
                repository.sessionsByDate(date).map { sessions ->
                    _ui.value.copy(sessions = sessions, subjects = subjects)
                }
            }.collect { _ui.value = it }
        }
    }

    fun selectDate(date: LocalDate)   = _ui.update { it.copy(selectedDate = date) }
    fun setView(mode: PlannerView)    = _ui.update { it.copy(viewMode = mode) }
    fun openAddModal()                = _ui.update { it.copy(showAddModal = true) }
    fun closeAddModal()               = _ui.update { it.copy(showAddModal = false) }
}

// Workaround to use snapshotFlow outside Compose
private fun <T> snapshotFlow(block: () -> T): Flow<T> = flow { emit(block()) }
private fun <T, R> Flow<T>.flatMapLatest(transform: suspend (T) -> Flow<R>): Flow<R> =
    this.map { transform(it) }.flattenMerge()
