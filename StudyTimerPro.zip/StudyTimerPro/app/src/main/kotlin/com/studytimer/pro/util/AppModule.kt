package com.studytimer.pro.util

import android.content.Context
import androidx.room.Room
import com.studytimer.pro.data.local.AppDatabase
import com.studytimer.pro.data.local.dao.FocusSessionDao
import com.studytimer.pro.data.local.dao.SubjectDao
import com.studytimer.pro.data.local.dao.UserProfileDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext ctx: Context): AppDatabase =
        Room.databaseBuilder(ctx, AppDatabase::class.java, "studytimer_db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides fun provideFocusSessionDao(db: AppDatabase): FocusSessionDao = db.focusSessionDao()
    @Provides fun provideSubjectDao(db: AppDatabase): SubjectDao            = db.subjectDao()
    @Provides fun provideUserProfileDao(db: AppDatabase): UserProfileDao    = db.userProfileDao()

    @Provides @Singleton
    fun provideContext(@ApplicationContext ctx: Context): Context = ctx
}
