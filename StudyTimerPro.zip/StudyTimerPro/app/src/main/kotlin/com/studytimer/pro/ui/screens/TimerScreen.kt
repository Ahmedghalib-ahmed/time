package com.studytimer.pro.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.studytimer.pro.data.local.entities.Subject
import com.studytimer.pro.service.AmbientSoundService.SoundTrack
import com.studytimer.pro.ui.components.CircularTimerRing
import com.studytimer.pro.ui.theme.*
import com.studytimer.pro.viewmodel.TimerMode
import com.studytimer.pro.viewmodel.TimerStatus
import com.studytimer.pro.viewmodel.TimerViewModel

@Composable
fun TimerScreen(
    preselectedSubject: Subject? = null,
    viewModel: TimerViewModel = hiltViewModel(),
) {
    val ui by viewModel.ui.collectAsState()
    var showAmbientPanel by remember { mutableStateOf(false) }

    // Apply pre-selected subject once
    LaunchedEffect(preselectedSubject) {
        if (preselectedSubject != null) viewModel.setSubject(preselectedSubject)
    }

    val progress = when (ui.mode) {
        TimerMode.COUNTUP -> 1f  // ring fills as time goes (visual only)
        else -> if (ui.totalSeconds > 0)
            ui.remainingSeconds.toFloat() / ui.totalSeconds else 0f
    }

    Box(Modifier.fillMaxSize().background(BgDeep)) {

        Column(
            modifier            = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(52.dp))

            // ── Header / subject tag ─────────────────────────────
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.CenterVertically,
            ) {
                Text("Focus Timer", style = MaterialTheme.typography.headlineSmall)
                ui.selectedSubject?.let { sub ->
                    Surface(
                        shape  = RoundedCornerShape(50),
                        color  = Color(android.graphics.Color.parseColor(sub.colorHex))
                            .copy(alpha = .2f),
                        border = BorderStroke(1.dp,
                            Color(android.graphics.Color.parseColor(sub.colorHex))),
                    ) {
                        Row(
                            Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(sub.emoji, fontSize = 14.sp)
                            Spacer(Modifier.width(6.dp))
                            Text(sub.name, style = MaterialTheme.typography.labelLarge,
                                color = Color(android.graphics.Color.parseColor(sub.colorHex)))
                        }
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            // ── Mode selector tabs ───────────────────────────────
            ModeSelector(
                current  = ui.mode,
                enabled  = ui.status == TimerStatus.IDLE,
                onSelect = viewModel::setMode,
            )

            Spacer(Modifier.height(32.dp))

            // ── Pomodoro round pips ──────────────────────────────
            if (ui.mode == TimerMode.POMODORO) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    repeat(4) { i ->
                        Box(
                            modifier = Modifier
                                .size(if (i < ui.pomodoroRound) 10.dp else 8.dp)
                                .background(
                                    if (i < ui.pomodoroRound) Amber else Surface3,
                                    RoundedCornerShape(50),
                                )
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    if (ui.isBreakPhase) "☕ Break Time" else "🍅 Round ${ui.pomodoroRound} of 4",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (ui.isBreakPhase) Amber else TextSecondary,
                )
                Spacer(Modifier.height(20.dp))
            }

            // ── Circular Timer ───────────────────────────────────
            CircularTimerRing(
                progress    = progress,
                size        = 260.dp,
                strokeWidth = 16.dp,
                isBreak     = ui.isBreakPhase,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    // Mode countup displays elapsed
                    val display = if (ui.mode == TimerMode.COUNTUP)
                        formatSeconds(ui.countUpSeconds)
                    else
                        formatSeconds(ui.remainingSeconds)

                    Text(
                        text       = display,
                        fontSize   = 58.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        color      = when {
                            ui.isBreakPhase                 -> Amber
                            ui.status == TimerStatus.PAUSED -> TextSecondary
                            else                            -> Cyan
                        },
                        letterSpacing = 2.sp,
                    )
                    Text(
                        text  = when (ui.mode) {
                            TimerMode.POMODORO  -> if (ui.isBreakPhase) "break" else "focus"
                            TimerMode.COUNTDOWN -> "remaining"
                            TimerMode.COUNTUP   -> "elapsed"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                    )
                    if (ui.status == TimerStatus.PAUSED) {
                        Spacer(Modifier.height(4.dp))
                        Text("PAUSED", color = Amber,
                            style = MaterialTheme.typography.labelSmall,
                            letterSpacing = 2.sp)
                    }
                }
            }

            Spacer(Modifier.height(32.dp))

            // ── Countdown custom minutes ─────────────────────────
            AnimatedVisibility(ui.mode == TimerMode.COUNTDOWN && ui.status == TimerStatus.IDLE) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Duration", style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        listOf(15, 25, 45, 60, 90).forEach { m ->
                            val sel = ui.countdownMinutes == m
                            Surface(
                                onClick = { viewModel.setCountdownMinutes(m) },
                                shape   = RoundedCornerShape(12.dp),
                                color   = if (sel) Purple else Surface2,
                                border  = if (sel) null else BorderStroke(1.dp, BorderSubtle),
                            ) {
                                Text(
                                    "${m}m",
                                    Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                    style     = MaterialTheme.typography.labelLarge,
                                    color     = if (sel) Color.White else TextSecondary,
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                }
            }

            // ── Controls ─────────────────────────────────────────
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment     = Alignment.CenterVertically,
            ) {
                // Stop (only shown when not idle)
                AnimatedVisibility(ui.status != TimerStatus.IDLE && ui.status != TimerStatus.FINISHED) {
                    IconButton(
                        onClick  = viewModel::stop,
                        modifier = Modifier
                            .size(52.dp)
                            .background(Surface2, RoundedCornerShape(14.dp)),
                    ) {
                        Icon(Icons.Default.Stop, "Stop", tint = Red)
                    }
                }

                // Main play/pause button
                val isRunning = ui.status == TimerStatus.RUNNING
                PulsingButton(
                    isRunning = isRunning,
                    modifier  = Modifier.weight(1f).height(58.dp),
                    onClick   = {
                        when (ui.status) {
                            TimerStatus.IDLE, TimerStatus.FINISHED -> viewModel.start()
                            TimerStatus.RUNNING                    -> viewModel.pause()
                            TimerStatus.PAUSED                     -> viewModel.resume()
                            TimerStatus.BREAK                      -> viewModel.start()
                        }
                    },
                    label = when (ui.status) {
                        TimerStatus.IDLE     -> "▶  Start"
                        TimerStatus.RUNNING  -> "⏸  Pause"
                        TimerStatus.PAUSED   -> "▶  Resume"
                        TimerStatus.BREAK    -> "Start Break"
                        TimerStatus.FINISHED -> "▶  Again"
                    }
                )
            }

            Spacer(Modifier.height(24.dp))

            // ── Feature toggles row ──────────────────────────────
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                // Ambient Sound toggle
                FeatureToggle(
                    label    = "Sound",
                    emoji    = "🎵",
                    enabled  = ui.ambientEnabled,
                    modifier = Modifier.weight(1f),
                    onClick  = {
                        if (!ui.ambientEnabled) showAmbientPanel = true
                        viewModel.toggleAmbient()
                    },
                )
                // Focus Guard toggle (Pomodoro only)
                FeatureToggle(
                    label   = "Guard",
                    emoji   = "🛡",
                    enabled = ui.focusGuardEnabled,
                    enabled_label = "On",
                    modifier = Modifier.weight(1f),
                    onClick = viewModel::toggleFocusGuard,
                )
            }

            // ── Ambient panel ────────────────────────────────────
            AnimatedVisibility(visible = showAmbientPanel) {
                AmbientSoundPanel(
                    currentTrack = ui.ambientTrack,
                    volume       = ui.ambientVolume,
                    onTrack      = viewModel::setAmbientTrack,
                    onVolume     = viewModel::setAmbientVolume,
                    onClose      = { showAmbientPanel = false },
                )
            }

            Spacer(Modifier.height(120.dp))
        }

        // ── XP / Level-up overlay ────────────────────────────────
        ui.lastXpEarned?.let { xp ->
            XpOverlay(
                xp         = xp,
                didLevelUp = ui.didLevelUp,
                newLevel   = ui.newLevel,
                onDismiss  = viewModel::dismissXpOverlay,
            )
        }
    }
}

// ── Sub-components ────────────────────────────────────────────

@Composable
private fun ModeSelector(current: TimerMode, enabled: Boolean, onSelect: (TimerMode) -> Unit) {
    val modes = listOf(
        TimerMode.POMODORO  to "🍅 Pomodoro",
        TimerMode.COUNTDOWN to "⏱ Countdown",
        TimerMode.COUNTUP   to "⏫ Count-up",
    )
    Surface(
        shape  = RoundedCornerShape(14.dp),
        color  = Surface1,
        border = BorderStroke(1.dp, BorderSubtle),
    ) {
        Row(Modifier.padding(4.dp)) {
            modes.forEach { (mode, label) ->
                val sel = current == mode
                Surface(
                    onClick  = { if (enabled) onSelect(mode) },
                    shape    = RoundedCornerShape(10.dp),
                    color    = if (sel) Purple else Color.Transparent,
                    modifier = Modifier.weight(1f),
                ) {
                    Text(
                        label,
                        Modifier.padding(vertical = 9.dp).fillMaxWidth(),
                        style     = MaterialTheme.typography.labelMedium,
                        color     = if (sel) Color.White else TextSecondary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        maxLines  = 1,
                    )
                }
            }
        }
    }
}

@Composable
private fun PulsingButton(
    isRunning: Boolean, modifier: Modifier, onClick: () -> Unit, label: String,
) {
    val scale by animateFloatAsState(
        targetValue   = if (isRunning) 1f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label         = "btn_scale",
    )
    Button(
        onClick  = onClick,
        modifier = modifier.scale(scale),
        shape    = RoundedCornerShape(16.dp),
        colors   = ButtonDefaults.buttonColors(
            containerColor = if (isRunning) Surface2 else Purple,
        ),
        border = if (isRunning) BorderStroke(1.dp, BorderBright) else null,
    ) {
        Text(label, fontWeight = FontWeight.Bold, fontSize = 16.sp,
            color = if (isRunning) TextPrimary else Color.White)
    }
}

@Composable
private fun FeatureToggle(
    label: String, emoji: String, enabled: Boolean,
    enabled_label: String = "On",
    modifier: Modifier = Modifier, onClick: () -> Unit,
) {
    Surface(
        onClick  = onClick,
        shape    = RoundedCornerShape(14.dp),
        color    = if (enabled) Purple.copy(alpha = .2f) else Surface1,
        border   = BorderStroke(1.dp, if (enabled) Purple else BorderSubtle),
        modifier = modifier.height(52.dp),
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp),
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Text(emoji, fontSize = 18.sp)
            Spacer(Modifier.width(8.dp))
            Column {
                Text(label, style = MaterialTheme.typography.labelLarge,
                    color = if (enabled) Purple else TextSecondary)
                if (enabled) Text(enabled_label, style = MaterialTheme.typography.labelSmall,
                    color = Green)
            }
        }
    }
}

@Composable
private fun AmbientSoundPanel(
    currentTrack: String, volume: Float,
    onTrack: (String) -> Unit, onVolume: (Float) -> Unit, onClose: () -> Unit,
) {
    val tracks = SoundTrack.entries
    Card(
        modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
        shape    = RoundedCornerShape(18.dp),
        colors   = CardDefaults.cardColors(containerColor = Surface1),
        border   = BorderStroke(1.dp, BorderSubtle),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Ambient Sound", style = MaterialTheme.typography.titleSmall)
                IconButton(onClick = onClose, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Close, null, tint = TextSecondary)
                }
            }
            Spacer(Modifier.height(12.dp))
            // Track buttons
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                tracks.forEach { t ->
                    val sel = currentTrack == t.name
                    Surface(
                        onClick  = { onTrack(t.name) },
                        shape    = RoundedCornerShape(12.dp),
                        color    = if (sel) Cyan.copy(.2f) else Surface2,
                        border   = BorderStroke(1.dp, if (sel) Cyan else BorderSubtle),
                    ) {
                        Column(
                            Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text(t.emoji, fontSize = 20.sp)
                            Text(t.label, style = MaterialTheme.typography.labelSmall,
                                color = if (sel) Cyan else TextSecondary)
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🔇", fontSize = 14.sp)
                Slider(
                    value         = volume,
                    onValueChange = onVolume,
                    modifier      = Modifier.weight(1f).padding(horizontal = 8.dp),
                    colors        = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Cyan),
                )
                Text("🔊", fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun XpOverlay(xp: Int, didLevelUp: Boolean, newLevel: Int?, onDismiss: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = .75f))
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.Center,
    ) {
        Card(
            shape  = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Surface1),
            border = BorderStroke(1.dp, if (didLevelUp) Amber else Purple),
        ) {
            Column(
                modifier            = Modifier.padding(36.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(if (didLevelUp) "🌟" else "✅", fontSize = 56.sp)
                Text(
                    if (didLevelUp) "Level Up!" else "Session Complete!",
                    style      = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black,
                    color      = if (didLevelUp) Amber else Green,
                )
                Text("+$xp XP earned",
                    style = MaterialTheme.typography.titleMedium, color = TextSecondary)
                if (didLevelUp && newLevel != null) {
                    Spacer(Modifier.height(4.dp))
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Amber.copy(.15f),
                        border = BorderStroke(1.dp, Amber),
                    ) {
                        Text(
                            "You reached Level $newLevel!",
                            Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
                            color = Amber, fontWeight = FontWeight.Bold,
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = onDismiss,
                    colors  = ButtonDefaults.buttonColors(containerColor = Purple),
                    shape   = RoundedCornerShape(14.dp),
                ) {
                    Text("Continue", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun formatSeconds(secs: Int): String {
    val h = secs / 3600
    val m = (secs % 3600) / 60
    val s = secs % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s)
    else "%02d:%02d".format(m, s)
}
