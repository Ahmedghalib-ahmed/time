package com.studytimer.pro.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.studytimer.pro.data.local.entities.FocusSession
import com.studytimer.pro.data.repository.FocusRepository
import com.studytimer.pro.ui.theme.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import javax.inject.Inject

// ── CalendarViewModel ─────────────────────────────────────────
data class CalendarUiState(
    val displayMonth    : YearMonth             = YearMonth.now(),
    val selectedDate    : LocalDate             = LocalDate.now(),
    val activeDates     : Set<String>           = emptySet(),
    val dayMinutesMap   : Map<String, Int>      = emptyMap(),
    val selectedSessions: List<FocusSession>    = emptyList(),
    val goalMinutes     : Int                   = 120,
)

@HiltViewModel
class CalendarViewModel @Inject constructor(
    private val repository: FocusRepository,
) : androidx.lifecycle.ViewModel() {

    private val _ui = MutableStateFlow(CalendarUiState())
    val ui: StateFlow<CalendarUiState> = _ui.asStateFlow()

    init {
        androidx.lifecycle.viewModelScope.launch {
            combine(
                repository.userProfile,
                repository.dailySummaryLastNDays(365),
            ) { profile, summary ->
                val activeDates = summary.map { it.dateIso }.toSet()
                val dayMins     = summary.associate { it.dateIso to it.totalMinutes }
                _ui.update { it.copy(
                    activeDates  = activeDates,
                    dayMinutesMap= dayMins,
                    goalMinutes  = profile?.dailyGoalMinutes ?: 120,
                ) }
            }.collect()
        }
        loadSelectedDate(LocalDate.now())
    }

    fun prevMonth() = _ui.update { it.copy(displayMonth = it.displayMonth.minusMonths(1)) }
    fun nextMonth() = _ui.update { it.copy(displayMonth = it.displayMonth.plusMonths(1)) }

    fun selectDate(date: LocalDate) {
        _ui.update { it.copy(selectedDate = date) }
        loadSelectedDate(date)
    }

    private fun loadSelectedDate(date: LocalDate) {
        androidx.lifecycle.viewModelScope.launch {
            repository.sessionsByDate(date).collect { sessions ->
                _ui.update { it.copy(selectedSessions = sessions) }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
//  CalendarScreen
// ═══════════════════════════════════════════════════════════════
@Composable
fun CalendarScreen(viewModel: CalendarViewModel = hiltViewModel()) {
    val ui by viewModel.ui.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDeep)
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(52.dp))
        Text("Calendar", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(20.dp))

        // Month navigation
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment     = Alignment.CenterVertically,
        ) {
            IconButton(onClick = viewModel::prevMonth) {
                Icon(Icons.Default.ChevronLeft, null, tint = TextPrimary)
            }
            Text(
                ui.displayMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy")),
                style = MaterialTheme.typography.titleLarge,
            )
            IconButton(onClick = viewModel::nextMonth) {
                Icon(Icons.Default.ChevronRight, null, tint = TextPrimary)
            }
        }

        Spacer(Modifier.height(12.dp))

        // Day-of-week headers
        Row(Modifier.fillMaxWidth()) {
            val days = listOf("Mo","Tu","We","Th","Fr","Sa","Su")
            days.forEach { d ->
                Text(d, Modifier.weight(1f), textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
        }

        Spacer(Modifier.height(8.dp))

        // Calendar grid
        CalendarGrid(
            month       = ui.displayMonth,
            selectedDate= ui.selectedDate,
            activeDates = ui.activeDates,
            dayMinsMap  = ui.dayMinutesMap,
            goalMins    = ui.goalMinutes,
            onSelect    = viewModel::selectDate,
        )

        Spacer(Modifier.height(20.dp))

        // Legend
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            LegendDot(Green, "Goal hit")
            LegendDot(Purple.copy(.6f), "Partial")
            LegendDot(Surface3, "No session")
        }

        Spacer(Modifier.height(20.dp))

        // Agenda for selected date
        Text(
            ui.selectedDate.format(DateTimeFormatter.ofPattern("EEEE, MMM d")),
            style = MaterialTheme.typography.titleMedium,
        )
        Spacer(Modifier.height(10.dp))

        if (ui.selectedSessions.isEmpty()) {
            Box(
                Modifier.fillMaxWidth().padding(24.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text("No sessions on this day", color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(ui.selectedSessions) { s ->
                    AgendaItem(session = s)
                }
            }
        }
    }
}

@Composable
private fun CalendarGrid(
    month       : YearMonth,
    selectedDate: LocalDate,
    activeDates : Set<String>,
    dayMinsMap  : Map<String, Int>,
    goalMins    : Int,
    onSelect    : (LocalDate) -> Unit,
) {
    val firstDay   = month.atDay(1)
    val daysInMonth= month.lengthOfMonth()
    // Monday = 1 ... Sunday = 7; shift to Mon-based grid
    val startOffset = (firstDay.dayOfWeek.value - 1) % 7

    val cells = buildList {
        repeat(startOffset) { add(null) }
        for (d in 1..daysInMonth) add(month.atDay(d))
    }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        cells.chunked(7).forEach { week ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                repeat(7) { i ->
                    val date = week.getOrNull(i)
                    if (date == null) {
                        Spacer(Modifier.weight(1f))
                    } else {
                        val iso      = date.toString()
                        val mins     = dayMinsMap[iso] ?: 0
                        val hasData  = iso in activeDates
                        val hitGoal  = mins >= goalMins
                        val isToday  = date == LocalDate.now()
                        val isSel    = date == selectedDate

                        val bgColor = when {
                            isSel   -> Purple
                            hitGoal -> Green.copy(.25f)
                            hasData -> Purple.copy(.2f)
                            else    -> Color.Transparent
                        }
                        val borderColor = when {
                            isToday -> Purple
                            isSel   -> Purple
                            else    -> Color.Transparent
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .clip(CircleShape)
                                .background(bgColor)
                                .border(
                                    if (isToday && !isSel) 1.5.dp else 0.dp,
                                    borderColor, CircleShape,
                                )
                                .clickable { onSelect(date) },
                            contentAlignment = Alignment.Center,
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    "${date.dayOfMonth}",
                                    fontSize   = 13.sp,
                                    fontWeight = if (isToday || isSel) FontWeight.Bold else FontWeight.Normal,
                                    color      = when {
                                        isSel   -> Color.White
                                        hitGoal -> Green
                                        else    -> TextPrimary
                                    },
                                )
                                // Tiny dot indicator
                                if (hasData && !isSel) {
                                    Box(
                                        Modifier.size(4.dp)
                                            .background(if (hitGoal) Green else Purple, CircleShape)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AgendaItem(session: FocusSession) {
    val time = java.time.Instant.ofEpochMilli(session.startEpochMs)
        .atZone(java.time.ZoneId.systemDefault())
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(12.dp),
        colors   = CardDefaults.cardColors(containerColor = Surface1),
        border   = BorderStroke(1.dp, BorderSubtle),
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Purple.copy(.15f),
            ) {
                Text(
                    time.format(DateTimeFormatter.ofPattern("HH:mm")),
                    Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    style = MaterialTheme.typography.labelLarge, color = Purple,
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("${session.durationMinutes} min  ·  ${session.timerMode}",
                    style = MaterialTheme.typography.bodyMedium)
                Text(if (session.wasCompleted) "Completed ✓" else "Partial",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (session.wasCompleted) Green else Amber)
            }
            Text("+${session.xpEarned} XP",
                style = MaterialTheme.typography.labelMedium, color = Amber)
        }
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).background(color, CircleShape))
        Spacer(Modifier.width(5.dp))
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}
