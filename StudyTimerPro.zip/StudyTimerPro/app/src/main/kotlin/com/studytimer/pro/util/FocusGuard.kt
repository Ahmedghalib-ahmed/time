package com.studytimer.pro.util

import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import javax.inject.Inject
import javax.inject.Singleton

/**
 * FocusGuard monitors the *process* lifecycle.
 * When enabled and the user sends the app to background (onStop fires on
 * ProcessLifecycleOwner), it immediately fires a high-priority push nudge
 * and invokes [onFocusLost] so the TimerViewModel can react (e.g. pause).
 *
 * Usage:
 *   focusGuard.onFocusLost = { /* optionally auto-pause */ }
 *   focusGuard.enable()   // call when Pomodoro starts with guard ON
 *   focusGuard.disable()  // call when session ends or guard toggled OFF
 */
@Singleton
class FocusGuard @Inject constructor(
    private val notificationHelper: NotificationHelper,
) : DefaultLifecycleObserver {

    var isEnabled: Boolean = false
        private set

    /** Called on the main thread when the user backgrounds the app. */
    var onFocusLost: (() -> Unit)? = null

    fun enable() {
        if (isEnabled) return
        isEnabled = true
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
    }

    fun disable() {
        if (!isEnabled) return
        isEnabled = false
        ProcessLifecycleOwner.get().lifecycle.removeObserver(this)
    }

    override fun onStop(owner: LifecycleOwner) {
        // onStop fires when the entire app goes to background
        if (isEnabled) {
            notificationHelper.showFocusGuardAlert()
            onFocusLost?.invoke()
        }
    }
}
