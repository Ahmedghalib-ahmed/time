package com.studytimer.pro.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.studytimer.pro.data.local.entities.FocusSession
import com.studytimer.pro.data.local.entities.Subject
import com.studytimer.pro.ui.theme.*
import com.studytimer.pro.viewmodel.PlannerUiState
import com.studytimer.pro.viewmodel.PlannerView
import com.studytimer.pro.viewmodel.PlannerViewModel
import java.time.LocalDate
import java.time.format.DateTimeFormatter

// ═══════════════════════════════════════════════════════════════
//  PlannerScreen
// ═══════════════════════════════════════════════════════════════
@Composable
fun PlannerScreen(viewModel: PlannerViewModel = hiltViewModel()) {
    val ui by viewModel.ui.collectAsState()

    Scaffold(
        containerColor = BgDeep,
        floatingActionButton = {
            FloatingActionButton(
                onClick          = viewModel::openAddModal,
                containerColor   = Purple,
                contentColor     = Color.White,
                shape            = RoundedCornerShape(16.dp),
            ) {
                Icon(Icons.Default.Add, "Add Session")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(52.dp))
            Text("Planner", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(16.dp))

            // View mode toggle
            ViewToggle(current = ui.viewMode, onSelect = viewModel::setView)

            Spacer(Modifier.height(16.dp))

            // Date navigation
            DateNav(
                date      = ui.selectedDate,
                mode      = ui.viewMode,
                onPrev    = { viewModel.selectDate(prevDate(ui.selectedDate, ui.viewMode)) },
                onNext    = { viewModel.selectDate(nextDate(ui.selectedDate, ui.viewMode)) },
                onToday   = { viewModel.selectDate(LocalDate.now()) },
            )

            Spacer(Modifier.height(16.dp))

            // Session list
            if (ui.sessions.isEmpty()) {
                EmptyDayPlaceholder(ui.selectedDate)
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(ui.sessions) { session ->
                        SessionCard(session = session, subjects = ui.subjects)
                    }
                    item { Spacer(Modifier.height(100.dp)) }
                }
            }
        }
    }

    // Add session modal
    if (ui.showAddModal) {
        AddSessionModal(
            subjects  = ui.subjects,
            onDismiss = viewModel::closeAddModal,
            onConfirm = { viewModel.closeAddModal() }, // extend: save planned session
        )
    }
}

@Composable
private fun ViewToggle(current: PlannerView, onSelect: (PlannerView) -> Unit) {
    Surface(shape = RoundedCornerShape(12.dp), color = Surface1,
        border = BorderStroke(1.dp, BorderSubtle)) {
        Row(Modifier.padding(4.dp)) {
            PlannerView.entries.forEach { mode ->
                val sel = current == mode
                Surface(
                    onClick  = { onSelect(mode) },
                    shape    = RoundedCornerShape(8.dp),
                    color    = if (sel) Purple else Color.Transparent,
                    modifier = Modifier.weight(1f),
                ) {
                    Text(
                        mode.name.lowercase().replaceFirstChar { it.uppercase() },
                        Modifier.padding(vertical = 8.dp).fillMaxWidth(),
                        style     = MaterialTheme.typography.labelLarge,
                        color     = if (sel) Color.White else TextSecondary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                }
            }
        }
    }
}

@Composable
private fun DateNav(
    date: LocalDate, mode: PlannerView,
    onPrev: () -> Unit, onNext: () -> Unit, onToday: () -> Unit,
) {
    val fmt = DateTimeFormatter.ofPattern(
        when (mode) {
            PlannerView.DAY   -> "EEE, MMM d"
            PlannerView.WEEK  -> "'Week of' MMM d"
            PlannerView.MONTH -> "MMMM yyyy"
        }
    )
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment     = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onPrev) {
            Icon(Icons.Default.ChevronLeft, null, tint = TextPrimary)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(date.format(fmt), style = MaterialTheme.typography.titleMedium)
            if (date != LocalDate.now()) {
                TextButton(onClick = onToday, contentPadding = PaddingValues(0.dp)) {
                    Text("Back to Today", color = Purple,
                        style = MaterialTheme.typography.labelMedium)
                }
            }
        }
        IconButton(onClick = onNext) {
            Icon(Icons.Default.ChevronRight, null, tint = TextPrimary)
        }
    }
}

@Composable
private fun SessionCard(session: FocusSession, subjects: List<Subject>) {
    val subject = subjects.find { it.id == session.subjectId }
    val subjectColor = subject?.colorHex?.let {
        Color(android.graphics.Color.parseColor(it))
    } ?: Purple

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(14.dp),
        colors   = CardDefaults.cardColors(containerColor = Surface1),
        border   = BorderStroke(1.dp, BorderSubtle),
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            // Color bar
            Box(
                Modifier.width(4.dp).height(48.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(subjectColor)
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    subject?.let { "${it.emoji} ${it.name}" } ?: "General",
                    style = MaterialTheme.typography.titleSmall,
                )
                Spacer(Modifier.height(2.dp))
                val startTime = java.time.Instant.ofEpochMilli(session.startEpochMs)
                    .atZone(java.time.ZoneId.systemDefault())
                Text(
                    "${startTime.format(DateTimeFormatter.ofPattern("HH:mm"))}  ·  " +
                    "${session.durationMinutes} min  ·  ${session.timerMode}",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            // XP pill
            Surface(
                shape = RoundedCornerShape(50),
                color = Amber.copy(.15f),
                border = BorderStroke(1.dp, Amber.copy(.4f)),
            ) {
                Text("+${session.xpEarned} XP",
                    Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelSmall, color = Amber)
            }
        }
    }
}

@Composable
private fun EmptyDayPlaceholder(date: LocalDate) {
    Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("📅", fontSize = 48.sp)
            Spacer(Modifier.height(12.dp))
            Text(if (date == LocalDate.now()) "No sessions yet today"
                else "No sessions on this day",
                style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            Text("Tap + to add a session", style = MaterialTheme.typography.bodySmall,
                color = TextDisabled)
        }
    }
}

@Composable
private fun AddSessionModal(
    subjects: List<Subject>, onDismiss: () -> Unit, onConfirm: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor   = Surface1,
        title  = { Text("Add Session") },
        text   = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Coming soon: Schedule a planned study session.",
                    style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                Text("For now, sessions are auto-logged when you complete a timer.",
                    style = MaterialTheme.typography.bodySmall, color = TextDisabled)
            }
        },
        confirmButton = {
            Button(onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                Text("Got it")
            }
        },
    )
}

private fun prevDate(date: LocalDate, mode: PlannerView) = when (mode) {
    PlannerView.DAY   -> date.minusDays(1)
    PlannerView.WEEK  -> date.minusWeeks(1)
    PlannerView.MONTH -> date.minusMonths(1)
}
private fun nextDate(date: LocalDate, mode: PlannerView) = when (mode) {
    PlannerView.DAY   -> date.plusDays(1)
    PlannerView.WEEK  -> date.plusWeeks(1)
    PlannerView.MONTH -> date.plusMonths(1)
}
