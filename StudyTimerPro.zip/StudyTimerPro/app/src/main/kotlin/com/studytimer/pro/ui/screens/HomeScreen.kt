package com.studytimer.pro.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.studytimer.pro.data.local.entities.Subject
import com.studytimer.pro.ui.components.CircularTimerRing
import com.studytimer.pro.ui.components.MiniProgressRing
import com.studytimer.pro.ui.theme.*
import com.studytimer.pro.util.XPCalculator
import com.studytimer.pro.viewmodel.HomeViewModel

@Composable
fun HomeScreen(
    onStartTimer    : (Subject?) -> Unit,
    viewModel       : HomeViewModel = hiltViewModel(),
) {
    val ui by viewModel.ui.collectAsState()
    var showAddSubject by remember { mutableStateOf(false) }
    var selectedSubject by remember { mutableStateOf<Subject?>(null) }

    val progressFraction = if (ui.dailyGoal > 0)
        (ui.minutesToday.toFloat() / ui.dailyGoal).coerceIn(0f, 1f) else 0f

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDeep)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(52.dp))

        // ── Top bar ──────────────────────────────────────────────
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Good ${greeting()} 👋", style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary)
                Text(ui.profile?.displayName ?: "Focuser",
                    style = MaterialTheme.typography.headlineMedium)
            }
            // XP Level badge
            LevelBadge(
                level    = ui.profile?.level ?: 1,
                progress = ui.levelProgress,
                xpLeft   = ui.xpToNextLevel,
            )
        }

        Spacer(Modifier.height(28.dp))

        // ── Daily focus ring ─────────────────────────────────────
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape    = RoundedCornerShape(24.dp),
            colors   = CardDefaults.cardColors(containerColor = Surface1),
        ) {
            Column(
                modifier            = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Today's Focus Goal", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(20.dp))

                CircularTimerRing(
                    progress    = progressFraction,
                    size        = 200.dp,
                    strokeWidth = 16.dp,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text  = formatMins(ui.minutesToday),
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Black,
                            color = if (progressFraction >= 1f) Green else TextPrimary,
                        )
                        Text("of ${formatMins(ui.dailyGoal)}", color = TextSecondary,
                            style = MaterialTheme.typography.bodySmall)
                        if (progressFraction >= 1f) {
                            Text("✅ Goal hit!", color = Green,
                                style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))

                // Metrics row
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ) {
                    MetricChip("🔥", "${ui.streak}", "Streak")
                    MetricChip("✅", "${ui.sessionsToday}", "Done")
                    MetricChip("⏳", "${(ui.dailyGoal - ui.minutesToday).coerceAtLeast(0)} min", "Left")
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // ── Subject selector ─────────────────────────────────────
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically) {
            Text("Study Subject", style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = { showAddSubject = true }) {
                Icon(Icons.Default.Add, null, tint = Purple, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Add", color = Purple)
            }
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            // "No subject" chip
            item {
                SubjectChip(
                    label    = "General",
                    emoji    = "📖",
                    color    = Color(0xFF888888),
                    selected = selectedSubject == null,
                    onClick  = { selectedSubject = null },
                )
            }
            items(ui.subjects) { sub ->
                SubjectChip(
                    label    = sub.name,
                    emoji    = sub.emoji,
                    color    = Color(android.graphics.Color.parseColor(sub.colorHex)),
                    selected = selectedSubject?.id == sub.id,
                    onClick  = { selectedSubject = if (selectedSubject?.id == sub.id) null else sub },
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        // ── Quick Start button ───────────────────────────────────
        Button(
            onClick = { onStartTimer(selectedSubject) },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape    = RoundedCornerShape(16.dp),
            colors   = ButtonDefaults.buttonColors(containerColor = Purple),
        ) {
            Icon(Icons.Default.PlayArrow, null)
            Spacer(Modifier.width(10.dp))
            Text("Start Focusing", fontWeight = FontWeight.Bold, fontSize = 17.sp)
        }

        Spacer(Modifier.height(20.dp))

        // ── Last 7 days mini bar chart ───────────────────────────
        if (ui.last7DayMinutes.isNotEmpty()) {
            Text("Last 7 Days", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(12.dp))
            MiniBarChart(data = ui.last7DayMinutes)
            Spacer(Modifier.height(20.dp))
        }

        // ── Motivational quote ───────────────────────────────────
        val (quote, author) = ui.motivationalQuote
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape    = RoundedCornerShape(16.dp),
            colors   = CardDefaults.cardColors(containerColor = Surface2),
            border   = BorderStroke(1.dp, BorderSubtle),
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("💬", fontSize = 24.sp)
                Spacer(Modifier.height(8.dp))
                Text(""$quote"", style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(6.dp))
                Text("— $author", style = MaterialTheme.typography.labelSmall)
            }
        }

        Spacer(Modifier.height(120.dp)) // nav bar clearance
    }

    // ── Add Subject dialog ───────────────────────────────────────
    if (showAddSubject) {
        AddSubjectDialog(
            onDismiss = { showAddSubject = false },
            onAdd     = { name, emoji, hex ->
                viewModel.addSubject(name, emoji, hex)
                showAddSubject = false
            }
        )
    }
}

// ── Sub-components ────────────────────────────────────────────

@Composable
private fun LevelBadge(level: Int, progress: Float, xpLeft: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(contentAlignment = Alignment.Center) {
            MiniProgressRing(progress, size = 56.dp, stroke = 5.dp, color = Amber)
            Text("$level", fontWeight = FontWeight.Black, fontSize = 16.sp, color = Amber)
        }
        Text("Lv.$level  ·  ${XPCalculator.levelTitle(level)}",
            style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun MetricChip(emoji: String, value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(emoji, fontSize = 20.sp)
        Text(value, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun SubjectChip(
    label: String, emoji: String, color: Color, selected: Boolean, onClick: () -> Unit,
) {
    val bg = if (selected) color.copy(alpha = .25f) else Surface2
    val border = if (selected) BorderStroke(1.5.dp, color) else BorderStroke(1.dp, BorderSubtle)
    Surface(
        onClick = onClick,
        shape   = RoundedCornerShape(50),
        color   = bg,
        border  = border,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier          = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
        ) {
            Text(emoji, fontSize = 15.sp)
            Spacer(Modifier.width(6.dp))
            Text(label, style = MaterialTheme.typography.labelLarge,
                color = if (selected) color else TextPrimary,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun MiniBarChart(data: List<Pair<String, Int>>) {
    val maxMins = data.maxOfOrNull { it.second }?.coerceAtLeast(1) ?: 1
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(16.dp),
        colors   = CardDefaults.cardColors(containerColor = Surface1),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment     = Alignment.Bottom,
        ) {
            data.forEach { (label, mins) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${mins}m", style = MaterialTheme.typography.labelSmall,
                        color = if (mins > 0) Purple else TextDisabled)
                    Spacer(Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .width(28.dp)
                            .height((60 * (mins.toFloat() / maxMins)).dp.coerceAtLeast(4.dp))
                            .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                            .background(if (mins > 0) Purple.copy(alpha = .8f) else Surface3)
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(label, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun AddSubjectDialog(onDismiss: () -> Unit, onAdd: (String, String, String) -> Unit) {
    var name  by remember { mutableStateOf("") }
    var emoji by remember { mutableStateOf("📚") }
    var colorIdx by remember { mutableIntStateOf(0) }
    val colorOptions = listOf("#7C4DFF","#00BCD4","#FF7043","#4CAF50","#E91E63","#FFB300")

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor   = Surface1,
        title = { Text("Add Subject") },
        text  = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it },
                    label = { Text("Subject name") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = emoji, onValueChange = { emoji = it },
                    label = { Text("Emoji") }, singleLine = true,
                    modifier = Modifier.width(80.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    colorOptions.forEachIndexed { i, hex ->
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(Color(android.graphics.Color.parseColor(hex)))
                                .border(if (i == colorIdx) 3.dp else 0.dp, Color.White, CircleShape)
                                .clickable { colorIdx = i }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { if (name.isNotBlank()) onAdd(name, emoji, colorOptions[colorIdx]) },
                colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                Text("Add")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

private fun greeting() = when (java.time.LocalTime.now().hour) {
    in 5..11  -> "Morning"
    in 12..16 -> "Afternoon"
    in 17..20 -> "Evening"
    else      -> "Night"
}

private fun formatMins(mins: Int) = if (mins >= 60) "${mins/60}h ${mins%60}m" else "${mins}m"
