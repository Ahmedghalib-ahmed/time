package com.studytimer.pro.navigation

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.*
import androidx.navigation.compose.*
import com.studytimer.pro.data.local.entities.Subject
import com.studytimer.pro.ui.screens.*
import com.studytimer.pro.ui.theme.*

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Home    : Screen("home",     "Home",    Icons.Default.Home)
    object Timer   : Screen("timer",    "Timer",   Icons.Default.Timer)
    object Planner : Screen("planner",  "Planner", Icons.Default.CalendarMonth)
    object Calendar: Screen("calendar", "Calendar",Icons.Default.DateRange)
    object Stats   : Screen("stats",    "Stats",   Icons.Default.BarChart)
}

val bottomNavItems = listOf(
    Screen.Home, Screen.Timer, Screen.Planner, Screen.Calendar, Screen.Stats,
)

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        containerColor = BgDeep,
        bottomBar = {
            NavigationBar(
                containerColor = Surface1,
                tonalElevation = 0.dp,
            ) {
                bottomNavItems.forEach { screen ->
                    val selected = currentRoute == screen.route
                    NavigationBarItem(
                        selected  = selected,
                        onClick   = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.startDestinationId) { saveState = true }
                                launchSingleTop = true
                                restoreState    = true
                            }
                        },
                        icon  = {
                            Icon(screen.icon, screen.label,
                                tint = if (selected) Purple else TextDisabled)
                        },
                        label = {
                            Text(screen.label,
                                color = if (selected) Purple else TextDisabled,
                                style = MaterialTheme.typography.labelSmall)
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor   = Purple,
                            indicatorColor      = Purple.copy(alpha = .15f),
                            unselectedIconColor = TextDisabled,
                        ),
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController    = navController,
            startDestination = Screen.Home.route,
            modifier         = Modifier.padding(innerPadding),
            enterTransition  = { fadeIn(tween(220)) + slideInHorizontally(tween(220)) { 60 } },
            exitTransition   = { fadeOut(tween(180)) },
            popEnterTransition  = { fadeIn(tween(220)) + slideInHorizontally(tween(220)) { -60 } },
            popExitTransition   = { fadeOut(tween(180)) },
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    onStartTimer = { subject ->
                        navController.navigate(Screen.Timer.route)
                        // Subject is passed via shared ViewModel in production;
                        // simplified here with route arg
                    }
                )
            }
            composable(Screen.Timer.route) {
                TimerScreen()
            }
            composable(Screen.Planner.route) {
                PlannerScreen()
            }
            composable(Screen.Calendar.route) {
                CalendarScreen()
            }
            composable(Screen.Stats.route) {
                StatsScreen()
            }
        }
    }
}
