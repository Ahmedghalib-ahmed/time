package com.studytimer.pro.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.studytimer.pro.ui.theme.BgDeep
import com.studytimer.pro.ui.theme.Purple
import com.studytimer.pro.ui.theme.Cyan
import com.studytimer.pro.ui.theme.Amber
import com.studytimer.pro.ui.theme.Surface2

/**
 * Animated circular progress ring with gradient stroke.
 *
 * @param progress  0f (empty) → 1f (full)
 * @param size      outer diameter including stroke
 * @param strokeWidth ring thickness in dp
 * @param isBreak   when true switches gradient to amber (break phase)
 * @param content   composable center content (timer digits etc.)
 */
@Composable
fun CircularTimerRing(
    progress    : Float,
    modifier    : Modifier = Modifier,
    size        : Dp       = 260.dp,
    strokeWidth : Dp       = 14.dp,
    isBreak     : Boolean  = false,
    trackColor  : Color    = Surface2,
    content     : @Composable () -> Unit = {},
) {
    val animProgress by animateFloatAsState(
        targetValue  = progress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 800),
        label        = "ring_progress",
    )

    val gradientColors = if (isBreak)
        listOf(Amber, Color(0xFFFF7043))
    else
        listOf(Purple, Cyan)

    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.size(size)) {
            val stroke     = strokeWidth.toPx()
            val radius     = (this.size.minDimension - stroke) / 2f
            val center     = Offset(this.size.width / 2f, this.size.height / 2f)
            val topLeft    = Offset(center.x - radius, center.y - radius)
            val arcSize    = Size(radius * 2, radius * 2)

            // Track (background ring)
            drawArc(
                color      = trackColor,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter  = false,
                topLeft    = topLeft,
                size       = arcSize,
                style      = Stroke(width = stroke, cap = StrokeCap.Round),
            )

            // Progress arc (gradient)
            if (animProgress > 0f) {
                drawArc(
                    brush      = Brush.sweepGradient(gradientColors, center),
                    startAngle = -90f,
                    sweepAngle = 360f * animProgress,
                    useCenter  = false,
                    topLeft    = topLeft,
                    size       = arcSize,
                    style      = Stroke(width = stroke, cap = StrokeCap.Round),
                )
            }
        }
        content()
    }
}

/** Small ring used in the Home screen daily goal card */
@Composable
fun MiniProgressRing(
    progress : Float,
    size     : Dp    = 80.dp,
    stroke   : Dp    = 8.dp,
    color    : Color = Purple,
    trackColor: Color = Surface2,
) {
    val anim by animateFloatAsState(progress.coerceIn(0f, 1f),
        tween(600), label = "mini_ring")

    Canvas(modifier = Modifier.size(size)) {
        val sw     = stroke.toPx()
        val r      = (this.size.minDimension - sw) / 2f
        val center = Offset(this.size.width / 2f, this.size.height / 2f)
        val tl     = Offset(center.x - r, center.y - r)
        val sz     = Size(r * 2, r * 2)

        drawArc(trackColor, -90f, 360f, false, tl, sz,
            style = Stroke(sw, cap = StrokeCap.Round))
        if (anim > 0f) drawArc(color, -90f, 360f * anim, false, tl, sz,
            style = Stroke(sw, cap = StrokeCap.Round))
    }
}
