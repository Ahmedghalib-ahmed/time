package com.studytimer.pro.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDate

// ─────────────────────────────────────────────
//  FocusSession
// ─────────────────────────────────────────────
@Entity(tableName = "focus_sessions")
data class FocusSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long?,
    val startEpochMs: Long,
    val endEpochMs: Long,
    val durationMinutes: Int,
    val timerMode: String,          // "POMODORO" | "COUNTDOWN" | "COUNTUP"
    val xpEarned: Int,
    val dateIso: String,            // yyyy-MM-dd — fast date queries
    val pomodoroRound: Int = 0,     // 0 if not pomodoro
    val wasCompleted: Boolean = true
)

// ─────────────────────────────────────────────
//  Subject
// ─────────────────────────────────────────────
@Entity(tableName = "subjects")
data class Subject(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val emoji: String = "📚",
    val colorHex: String = "#7C4DFF",
    val totalMinutes: Int = 0,
    val totalSessions: Int = 0
)

// ─────────────────────────────────────────────
//  UserProfile  (single-row singleton: id = 1)
// ─────────────────────────────────────────────
@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val id: Int = 1,
    val displayName: String = "Focus User",
    val totalXP: Int = 0,
    val level: Int = 1,
    val currentStreak: Int = 0,
    val longestStreak: Int = 0,
    val totalFocusMinutes: Int = 0,
    val dailyGoalMinutes: Int = 120,
    val lastActiveDate: String = LocalDate.now().toString(),
    /** JSON array of unlocked achievement IDs, e.g. "[\"first_session\",\"streak_7\"]" */
    val unlockedAchievements: String = "[]"
)

// ─────────────────────────────────────────────
//  Achievement definition (in-memory, not DB)
// ─────────────────────────────────────────────
data class Achievement(
    val id: String,
    val title: String,
    val description: String,
    val emoji: String,
    val xpReward: Int,
    val condition: (UserProfile, List<FocusSession>) -> Boolean
)

object Achievements {
    val all = listOf(
        Achievement("first_session",  "First Step",      "Complete your first session",         "🌱", 50)  { _, s -> s.isNotEmpty() },
        Achievement("streak_3",       "On a Roll",       "Maintain a 3-day streak",             "🔥", 100) { p, _ -> p.currentStreak >= 3 },
        Achievement("streak_7",       "Week Warrior",    "Maintain a 7-day streak",             "⚡", 250) { p, _ -> p.currentStreak >= 7 },
        Achievement("streak_30",      "Iron Focus",      "30-day streak",                       "💎", 1000){ p, _ -> p.currentStreak >= 30 },
        Achievement("total_10h",      "Deep Diver",      "Accumulate 10 hours of focus",        "🏊", 200) { p, _ -> p.totalFocusMinutes >= 600 },
        Achievement("total_50h",      "Focus Master",    "Accumulate 50 hours of focus",        "🎓", 750) { p, _ -> p.totalFocusMinutes >= 3000 },
        Achievement("pomodoro_10",    "Tomato Farmer",   "Complete 10 Pomodoro sessions",       "🍅", 150) { _, s -> s.count { it.timerMode == "POMODORO" } >= 10 },
        Achievement("level_5",        "Rising Star",     "Reach Level 5",                       "⭐", 300) { p, _ -> p.level >= 5 },
        Achievement("level_10",       "Pro Focuser",     "Reach Level 10",                      "🌟", 500) { p, _ -> p.level >= 10 },
        Achievement("night_owl",      "Night Owl",       "Complete a session after midnight",   "🦉", 75)  { _, s -> s.any { it.startEpochMs % 86_400_000 < 3_600_000 * 4 } },
    )
}
