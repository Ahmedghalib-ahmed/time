package com.studytimer.pro.viewmodel

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.studytimer.pro.data.local.entities.Subject
import com.studytimer.pro.data.repository.FocusRepository
import com.studytimer.pro.service.AmbientSoundService
import com.studytimer.pro.service.TimerService
import com.studytimer.pro.util.FocusGuard
import com.studytimer.pro.util.NotificationHelper
import com.studytimer.pro.util.XPCalculator
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

// ── Enums ─────────────────────────────────────────────────────
enum class TimerMode   { POMODORO, COUNTDOWN, COUNTUP }
enum class TimerStatus { IDLE, RUNNING, PAUSED, BREAK, FINISHED }

data class TimerUiState(
    val mode            : TimerMode   = TimerMode.POMODORO,
    val status          : TimerStatus = TimerStatus.IDLE,
    val remainingSeconds: Int         = 25 * 60,
    val totalSeconds    : Int         = 25 * 60,
    val pomodoroRound   : Int         = 1,
    val isBreakPhase    : Boolean     = false,
    val selectedSubject : Subject?    = null,
    val countdownMinutes: Int         = 25,
    val countUpSeconds  : Int         = 0,
    // ambient
    val ambientEnabled  : Boolean     = false,
    val ambientTrack    : String      = AmbientSoundService.SoundTrack.WHITE_NOISE.name,
    val ambientVolume   : Float       = 0.5f,
    // focus guard
    val focusGuardEnabled: Boolean    = false,
    // XP overlay
    val lastXpEarned    : Int?        = null,
    val didLevelUp      : Boolean     = false,
    val newLevel        : Int?        = null,
)

@HiltViewModel
class TimerViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository   : FocusRepository,
    private val focusGuard   : FocusGuard,
    private val notifications: NotificationHelper,
) : ViewModel() {

    private val _ui = MutableStateFlow(TimerUiState())
    val ui: StateFlow<TimerUiState> = _ui.asStateFlow()

    private var sessionStartMs = 0L

    // ── BroadcastReceiver — listens to ticks from TimerService ───
    private val tickReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            val remaining = intent?.getIntExtra(TimerService.EXTRA_REMAINING, -1) ?: return
            if (remaining < 0) return

            if (_ui.value.mode == TimerMode.COUNTUP) {
                _ui.update { it.copy(countUpSeconds = it.countUpSeconds + 1) }
                return
            }

            _ui.update { it.copy(remainingSeconds = remaining) }
            if (remaining == 0) onSessionEnd()
        }
    }

    init {
        context.registerReceiver(tickReceiver, IntentFilter(TimerService.ACTION_TICK),
            Context.RECEIVER_NOT_EXPORTED)

        focusGuard.onFocusLost = { /* auto-pause if desired */
            if (_ui.value.status == TimerStatus.RUNNING) pause()
        }
    }

    // ── Mode & config ─────────────────────────────────────────────
    fun setMode(mode: TimerMode) {
        if (_ui.value.status != TimerStatus.IDLE) return
        val secs = when (mode) {
            TimerMode.POMODORO  -> 25 * 60
            TimerMode.COUNTDOWN -> _ui.value.countdownMinutes * 60
            TimerMode.COUNTUP   -> 0
        }
        _ui.update { it.copy(mode = mode, remainingSeconds = secs, totalSeconds = secs,
            status = TimerStatus.IDLE, pomodoroRound = 1, isBreakPhase = false) }
    }

    fun setCountdownMinutes(mins: Int) {
        _ui.update { it.copy(countdownMinutes = mins,
            remainingSeconds = mins * 60, totalSeconds = mins * 60) }
    }

    fun setSubject(subject: Subject?) = _ui.update { it.copy(selectedSubject = subject) }

    // ── Playback controls ─────────────────────────────────────────
    fun start() {
        if (_ui.value.status == TimerStatus.RUNNING) return
        sessionStartMs = System.currentTimeMillis()
        _ui.update { it.copy(status = TimerStatus.RUNNING) }

        val ui = _ui.value
        val serviceIntent = Intent(context, TimerService::class.java).apply {
            action = TimerService.ACTION_START
            putExtra(TimerService.EXTRA_SECONDS, ui.remainingSeconds)
            putExtra(TimerService.EXTRA_MODE, modeLabel(ui))
            putExtra(TimerService.EXTRA_SUBJECT, ui.selectedSubject?.name)
        }
        context.startForegroundService(serviceIntent)

        if (ui.ambientEnabled) startAmbient()
        if (ui.focusGuardEnabled && ui.mode == TimerMode.POMODORO) focusGuard.enable()
    }

    fun pause() {
        if (_ui.value.status != TimerStatus.RUNNING) return
        _ui.update { it.copy(status = TimerStatus.PAUSED) }
        context.startService(Intent(context, TimerService::class.java).apply {
            action = TimerService.ACTION_STOP
        })
        stopAmbient()
    }

    fun resume() {
        if (_ui.value.status != TimerStatus.PAUSED) return
        start()
    }

    fun stop() {
        _ui.update { it.copy(status = TimerStatus.IDLE,
            pomodoroRound = 1, isBreakPhase = false, countUpSeconds = 0) }
        context.startService(Intent(context, TimerService::class.java).apply {
            action = TimerService.ACTION_STOP
        })
        stopAmbient()
        focusGuard.disable()
    }

    fun dismissXpOverlay() = _ui.update { it.copy(lastXpEarned = null, didLevelUp = false, newLevel = null) }

    // ── Session end logic ─────────────────────────────────────────
    private fun onSessionEnd() {
        val ui = _ui.value
        stopAmbient()
        focusGuard.disable()

        val durationMs   = System.currentTimeMillis() - sessionStartMs
        val minutes      = (durationMs / 60_000).toInt().coerceAtLeast(1)

        viewModelScope.launch {
            val prevProfile = repository.getOrCreateProfile()
            val xp = repository.saveCompletedSession(
                subjectId       = ui.selectedSubject?.id,
                startMs         = sessionStartMs,
                endMs           = System.currentTimeMillis(),
                durationMinutes = minutes,
                timerMode       = ui.mode.name,
                pomodoroRound   = ui.pomodoroRound,
            )
            val newProfile = repository.getOrCreateProfile()
            val leveledUp  = newProfile.level > prevProfile.level

            notifications.showSessionDone(minutes, xp)
            if (leveledUp) {
                notifications.showLevelUp(newProfile.level,
                    XPCalculator.levelTitle(newProfile.level))
            }
            checkAchievements(newProfile)

            if (ui.mode == TimerMode.POMODORO && !ui.isBreakPhase) {
                // Start break phase
                val breakSecs = if (ui.pomodoroRound % 4 == 0) 15 * 60 else 5 * 60
                _ui.update { it.copy(
                    status          = TimerStatus.BREAK,
                    isBreakPhase    = true,
                    remainingSeconds= breakSecs,
                    totalSeconds    = breakSecs,
                    lastXpEarned    = xp,
                    didLevelUp      = leveledUp,
                    newLevel        = if (leveledUp) newProfile.level else null,
                ) }
            } else if (ui.mode == TimerMode.POMODORO && ui.isBreakPhase) {
                // Break ended — next round
                val workSecs = 25 * 60
                _ui.update { it.copy(
                    status          = TimerStatus.IDLE,
                    isBreakPhase    = false,
                    pomodoroRound   = it.pomodoroRound + 1,
                    remainingSeconds= workSecs,
                    totalSeconds    = workSecs,
                ) }
            } else {
                _ui.update { it.copy(
                    status       = TimerStatus.FINISHED,
                    lastXpEarned = xp,
                    didLevelUp   = leveledUp,
                    newLevel     = if (leveledUp) newProfile.level else null,
                ) }
            }
        }
    }

    private suspend fun checkAchievements(profile: com.studytimer.pro.data.local.entities.UserProfile) {
        val sessions = repository.allSessions.first()
        val unlocked = repository.getUnlockedAchievements(profile)
        com.studytimer.pro.data.local.entities.Achievements.all.forEach { ach ->
            if (ach.id !in unlocked && ach.condition(profile, sessions)) {
                repository.unlockAchievement(ach.id)
                notifications.showAchievementUnlocked(ach.emoji, ach.title, ach.xpReward)
            }
        }
    }

    // ── Ambient Sound ─────────────────────────────────────────────
    fun toggleAmbient() = _ui.update { it.copy(ambientEnabled = !it.ambientEnabled) }.also {
        if (_ui.value.ambientEnabled && _ui.value.status == TimerStatus.RUNNING) startAmbient()
        else stopAmbient()
    }

    fun setAmbientTrack(track: String) {
        _ui.update { it.copy(ambientTrack = track) }
        if (_ui.value.ambientEnabled && _ui.value.status == TimerStatus.RUNNING) startAmbient()
    }

    fun setAmbientVolume(v: Float) {
        _ui.update { it.copy(ambientVolume = v) }
        context.startService(Intent(context, AmbientSoundService::class.java).apply {
            action = AmbientSoundService.ACTION_VOL
            putExtra(AmbientSoundService.EXTRA_VOLUME, v)
        })
    }

    private fun startAmbient() {
        context.startService(Intent(context, AmbientSoundService::class.java).apply {
            action = AmbientSoundService.ACTION_PLAY
            putExtra(AmbientSoundService.EXTRA_TRACK, _ui.value.ambientTrack)
            putExtra(AmbientSoundService.EXTRA_VOLUME, _ui.value.ambientVolume)
        })
    }
    private fun stopAmbient() {
        context.startService(Intent(context, AmbientSoundService::class.java).apply {
            action = AmbientSoundService.ACTION_STOP
        })
    }

    // ── Focus Guard toggle ────────────────────────────────────────
    fun toggleFocusGuard() = _ui.update { it.copy(focusGuardEnabled = !it.focusGuardEnabled) }

    // ── Helpers ───────────────────────────────────────────────────
    private fun modeLabel(ui: TimerUiState) = when (ui.mode) {
        TimerMode.POMODORO  -> if (ui.isBreakPhase) "Break" else "Pomodoro · R${ui.pomodoroRound}"
        TimerMode.COUNTDOWN -> "Countdown"
        TimerMode.COUNTUP   -> "Count-up"
    }

    override fun onCleared() {
        context.unregisterReceiver(tickReceiver)
        focusGuard.disable()
        super.onCleared()
    }
}
