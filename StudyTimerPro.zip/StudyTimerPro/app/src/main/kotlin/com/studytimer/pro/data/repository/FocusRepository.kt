package com.studytimer.pro.data.repository

import com.studytimer.pro.data.local.dao.DailySummary
import com.studytimer.pro.data.local.dao.FocusSessionDao
import com.studytimer.pro.data.local.dao.SubjectDao
import com.studytimer.pro.data.local.dao.UserProfileDao
import com.studytimer.pro.data.local.entities.FocusSession
import com.studytimer.pro.data.local.entities.Subject
import com.studytimer.pro.data.local.entities.UserProfile
import com.studytimer.pro.util.XPCalculator
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import java.time.LocalDate
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FocusRepository @Inject constructor(
    private val sessionDao: FocusSessionDao,
    private val subjectDao: SubjectDao,
    private val profileDao: UserProfileDao,
) {
    // ── Subjects ─────────────────────────────────────────────────
    val allSubjects: Flow<List<Subject>> = subjectDao.allSubjects()

    suspend fun addSubject(subject: Subject) = subjectDao.insert(subject)
    suspend fun updateSubject(subject: Subject) = subjectDao.update(subject)
    suspend fun deleteSubject(subject: Subject) = subjectDao.delete(subject)

    // ── Sessions ─────────────────────────────────────────────────
    val allSessions: Flow<List<FocusSession>> = sessionDao.allSessions()

    fun sessionsByDate(date: LocalDate): Flow<List<FocusSession>> =
        sessionDao.sessionsByDate(date.toString())

    fun sessionsInRange(from: LocalDate, to: LocalDate): Flow<List<FocusSession>> =
        sessionDao.sessionsInRange(from.toString(), to.toString())

    fun dailySummaryLastNDays(days: Int): Flow<List<DailySummary>> =
        sessionDao.dailySummary(LocalDate.now().minusDays(days.toLong()).toString())

    fun minutesToday(): Flow<Int> =
        sessionDao.minutesToday(LocalDate.now().toString()).map { it ?: 0 }

    fun sessionCountToday(): Flow<Int> =
        sessionDao.sessionCountToday(LocalDate.now().toString())

    /** Save a completed session, award XP and update streak. Returns XP earned. */
    suspend fun saveCompletedSession(
        subjectId: Long?,
        startMs: Long,
        endMs: Long,
        durationMinutes: Int,
        timerMode: String,
        pomodoroRound: Int = 0,
    ): Int {
        val profile = getOrCreateProfile()
        val streak  = calculateCurrentStreak()
        val xp      = XPCalculator.calculate(durationMinutes, timerMode, streak)

        val session = FocusSession(
            subjectId       = subjectId,
            startEpochMs    = startMs,
            endEpochMs      = endMs,
            durationMinutes = durationMinutes,
            timerMode       = timerMode,
            xpEarned        = xp,
            dateIso         = LocalDate.now().toString(),
            pomodoroRound   = pomodoroRound,
            wasCompleted    = true,
        )
        sessionDao.insert(session)

        // Update subject stats
        if (subjectId != null) subjectDao.addMinutes(subjectId, durationMinutes)

        // Update user profile
        val newTotalXP  = profile.totalXP + xp
        val newLevel    = XPCalculator.levelForXP(newTotalXP)
        val today       = LocalDate.now().toString()
        val newStreak   = streak
        val longestStreak = maxOf(profile.longestStreak, newStreak)

        profileDao.update(
            profile.copy(
                totalXP           = newTotalXP,
                level             = newLevel,
                currentStreak     = newStreak,
                longestStreak     = longestStreak,
                totalFocusMinutes = profile.totalFocusMinutes + durationMinutes,
                lastActiveDate    = today,
            )
        )
        return xp
    }

    // ── User Profile ─────────────────────────────────────────────
    val userProfile: Flow<UserProfile?> = profileDao.profile()

    suspend fun getOrCreateProfile(): UserProfile {
        return profileDao.profileOnce() ?: UserProfile().also { profileDao.insert(it) }
    }

    suspend fun updateDailyGoal(minutes: Int) {
        val p = getOrCreateProfile()
        profileDao.update(p.copy(dailyGoalMinutes = minutes))
    }

    suspend fun unlockAchievement(achievementId: String) {
        val p = getOrCreateProfile()
        val arr = JSONArray(p.unlockedAchievements)
        for (i in 0 until arr.length()) {
            if (arr.getString(i) == achievementId) return // already unlocked
        }
        arr.put(achievementId)
        profileDao.update(p.copy(unlockedAchievements = arr.toString()))
    }

    fun getUnlockedAchievements(profile: UserProfile): Set<String> {
        val arr = JSONArray(profile.unlockedAchievements)
        return (0 until arr.length()).map { arr.getString(it) }.toSet()
    }

    // ── Streak calculation ────────────────────────────────────────
    private suspend fun calculateCurrentStreak(): Int {
        val dates = sessionDao.allActiveDates()
            .map { LocalDate.parse(it) }
            .sortedDescending()

        if (dates.isEmpty()) return 0
        var streak = 1
        var expected = LocalDate.now().minusDays(1)
        for (date in dates.drop(1)) {
            if (date == expected) { streak++; expected = expected.minusDays(1) }
            else if (date < expected) break
        }
        return streak
    }
}
