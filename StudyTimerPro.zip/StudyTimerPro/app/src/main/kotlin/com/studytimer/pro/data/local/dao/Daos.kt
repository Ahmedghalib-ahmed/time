package com.studytimer.pro.data.local.dao

import androidx.room.*
import com.studytimer.pro.data.local.entities.FocusSession
import com.studytimer.pro.data.local.entities.Subject
import com.studytimer.pro.data.local.entities.UserProfile
import kotlinx.coroutines.flow.Flow

// ─────────────────────────────────────────────
//  FocusSessionDao
// ─────────────────────────────────────────────
@Dao
interface FocusSessionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: FocusSession): Long

    @Delete
    suspend fun delete(session: FocusSession)

    @Query("SELECT * FROM focus_sessions ORDER BY startEpochMs DESC")
    fun allSessions(): Flow<List<FocusSession>>

    @Query("SELECT * FROM focus_sessions WHERE dateIso = :date ORDER BY startEpochMs DESC")
    fun sessionsByDate(date: String): Flow<List<FocusSession>>

    @Query("""
        SELECT * FROM focus_sessions 
        WHERE dateIso >= :fromDate AND dateIso <= :toDate 
        ORDER BY startEpochMs DESC
    """)
    fun sessionsInRange(fromDate: String, toDate: String): Flow<List<FocusSession>>

    /** Returns (date, totalMinutes) for each active day in last N days */
    @Query("""
        SELECT dateIso, SUM(durationMinutes) as totalMinutes 
        FROM focus_sessions 
        WHERE dateIso >= :fromDate 
        GROUP BY dateIso 
        ORDER BY dateIso ASC
    """)
    fun dailySummary(fromDate: String): Flow<List<DailySummary>>

    @Query("SELECT SUM(durationMinutes) FROM focus_sessions WHERE dateIso = :date")
    fun minutesToday(date: String): Flow<Int?>

    @Query("SELECT COUNT(*) FROM focus_sessions WHERE dateIso = :date")
    fun sessionCountToday(date: String): Flow<Int>

    @Query("SELECT DISTINCT dateIso FROM focus_sessions ORDER BY dateIso DESC")
    suspend fun allActiveDates(): List<String>

    @Query("SELECT * FROM focus_sessions ORDER BY startEpochMs DESC LIMIT 1")
    suspend fun lastSession(): FocusSession?
}

data class DailySummary(val dateIso: String, val totalMinutes: Int)

// ─────────────────────────────────────────────
//  SubjectDao
// ─────────────────────────────────────────────
@Dao
interface SubjectDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(subject: Subject): Long

    @Update
    suspend fun update(subject: Subject)

    @Delete
    suspend fun delete(subject: Subject)

    @Query("SELECT * FROM subjects ORDER BY totalMinutes DESC")
    fun allSubjects(): Flow<List<Subject>>

    @Query("SELECT * FROM subjects WHERE id = :id")
    suspend fun byId(id: Long): Subject?

    @Query("UPDATE subjects SET totalMinutes = totalMinutes + :mins, totalSessions = totalSessions + 1 WHERE id = :id")
    suspend fun addMinutes(id: Long, mins: Int)
}

// ─────────────────────────────────────────────
//  UserProfileDao
// ─────────────────────────────────────────────
@Dao
interface UserProfileDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(profile: UserProfile)

    @Update
    suspend fun update(profile: UserProfile)

    @Query("SELECT * FROM user_profile WHERE id = 1")
    fun profile(): Flow<UserProfile?>

    @Query("SELECT * FROM user_profile WHERE id = 1")
    suspend fun profileOnce(): UserProfile?
}
