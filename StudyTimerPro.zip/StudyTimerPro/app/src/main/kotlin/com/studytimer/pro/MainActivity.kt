package com.studytimer.pro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.studytimer.pro.navigation.AppNavigation
import com.studytimer.pro.ui.theme.BgDeep
import com.studytimer.pro.ui.theme.StudyTimerTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            StudyTimerTheme {
                androidx.compose.material3.Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(BgDeep),
                ) {
                    AppNavigation()
                }
            }
        }
    }
}
