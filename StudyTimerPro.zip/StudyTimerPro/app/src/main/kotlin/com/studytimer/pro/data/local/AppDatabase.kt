package com.studytimer.pro.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.studytimer.pro.data.local.dao.FocusSessionDao
import com.studytimer.pro.data.local.dao.SubjectDao
import com.studytimer.pro.data.local.dao.UserProfileDao
import com.studytimer.pro.data.local.entities.FocusSession
import com.studytimer.pro.data.local.entities.Subject
import com.studytimer.pro.data.local.entities.UserProfile

@Database(
    entities = [FocusSession::class, Subject::class, UserProfile::class],
    version  = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun focusSessionDao(): FocusSessionDao
    abstract fun subjectDao(): SubjectDao
    abstract fun userProfileDao(): UserProfileDao
}
