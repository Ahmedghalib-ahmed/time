package com.studytimer.pro.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.studytimer.pro.MainActivity
import com.studytimer.pro.R
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationHelper @Inject constructor(private val context: Context) {

    companion object {
        const val CH_TIMER        = "ch_timer"
        const val CH_FOCUS_GUARD  = "ch_focus_guard"
        const val CH_ACHIEVEMENT  = "ch_achievement"
        const val CH_LEVEL_UP     = "ch_level_up"

        const val NOTIF_TIMER_ID       = 1001
        const val NOTIF_FOCUS_GUARD_ID = 1002
        const val NOTIF_ACHIEVEMENT_ID = 1003
        const val NOTIF_LEVEL_UP_ID    = 1004
        const val NOTIF_SESSION_DONE   = 1005
    }

    fun createChannels() {
        val nm = context.getSystemService(NotificationManager::class.java)
        listOf(
            NotificationChannel(CH_TIMER, "Timer",
                NotificationManager.IMPORTANCE_LOW).apply {
                description = "Live countdown shown while a session is running"
                setShowBadge(false)
            },
            NotificationChannel(CH_FOCUS_GUARD, "Focus Guard",
                NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Alert when you leave the app during a focus session"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 300, 150, 300)
            },
            NotificationChannel(CH_ACHIEVEMENT, "Achievements",
                NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Unlocked achievement badges"
            },
            NotificationChannel(CH_LEVEL_UP, "Level Up",
                NotificationManager.IMPORTANCE_HIGH).apply {
                description = "XP level-up celebration"
                enableVibration(true)
            },
        ).forEach { nm.createNotificationChannel(it) }
    }

    // ── Timer foreground notification ─────────────────────────────
    fun buildTimerNotification(
        timeLabel: String,     // e.g. "24:33"
        mode: String,          // "Pomodoro · Round 2"
        subjectName: String?,
    ) = NotificationCompat.Builder(context, CH_TIMER)
        .setSmallIcon(R.drawable.ic_timer)
        .setContentTitle("⏱ $timeLabel  ·  $mode")
        .setContentText(subjectName?.let { "Subject: $it" } ?: "Focus session in progress")
        .setOngoing(true)
        .setSilent(true)
        .setContentIntent(launchIntent())
        .build()

    // ── Session completed ─────────────────────────────────────────
    fun showSessionDone(minutes: Int, xpEarned: Int) {
        val notif = NotificationCompat.Builder(context, CH_ACHIEVEMENT)
            .setSmallIcon(R.drawable.ic_check)
            .setContentTitle("✅ Session Complete!")
            .setContentText("$minutes min focused  ·  +$xpEarned XP earned")
            .setAutoCancel(true)
            .setContentIntent(launchIntent())
            .build()
        NotificationManagerCompat.from(context).notify(NOTIF_SESSION_DONE, notif)
    }

    // ── Focus Guard nudge ─────────────────────────────────────────
    fun showFocusGuardAlert() {
        val notif = NotificationCompat.Builder(context, CH_FOCUS_GUARD)
            .setSmallIcon(R.drawable.ic_warning)
            .setContentTitle("🛡 Stay Focused!")
            .setContentText("You left the app. Your Pomodoro is still running — come back!")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVibrate(longArrayOf(0, 400, 200, 400))
            .setAutoCancel(true)
            .setContentIntent(launchIntent())
            .build()
        NotificationManagerCompat.from(context).notify(NOTIF_FOCUS_GUARD_ID, notif)
    }

    // ── Achievement unlocked ──────────────────────────────────────
    fun showAchievementUnlocked(emoji: String, title: String, xpReward: Int) {
        val notif = NotificationCompat.Builder(context, CH_ACHIEVEMENT)
            .setSmallIcon(R.drawable.ic_trophy)
            .setContentTitle("$emoji Achievement Unlocked!")
            .setContentText("$title  ·  +$xpReward XP")
            .setAutoCancel(true)
            .setContentIntent(launchIntent())
            .build()
        NotificationManagerCompat.from(context).notify(NOTIF_ACHIEVEMENT_ID, notif)
    }

    // ── Level-up ─────────────────────────────────────────────────
    fun showLevelUp(newLevel: Int, title: String) {
        val notif = NotificationCompat.Builder(context, CH_LEVEL_UP)
            .setSmallIcon(R.drawable.ic_star)
            .setContentTitle("🌟 Level Up! You're now Level $newLevel")
            .setContentText(title)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVibrate(longArrayOf(0, 200, 100, 200, 100, 400))
            .setAutoCancel(true)
            .setContentIntent(launchIntent())
            .build()
        NotificationManagerCompat.from(context).notify(NOTIF_LEVEL_UP_ID, notif)
    }

    fun cancelTimer() = NotificationManagerCompat.from(context).cancel(NOTIF_TIMER_ID)

    private fun launchIntent(): PendingIntent = PendingIntent.getActivity(
        context, 0,
        Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}
