package com.studytimer.pro.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary          = Purple,
    onPrimary        = Color.White,
    primaryContainer = PurpleDim,
    onPrimaryContainer = PurpleLight,
    secondary        = Cyan,
    onSecondary      = BgDeep,
    tertiary         = Amber,
    background       = BgDeep,
    onBackground     = TextPrimary,
    surface          = Surface1,
    onSurface        = TextPrimary,
    surfaceVariant   = Surface2,
    onSurfaceVariant = TextSecondary,
    outline          = BorderBright,
    outlineVariant   = BorderSubtle,
    error            = Red,
    onError          = Color.White,
)

@Composable
fun StudyTimerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography  = AppTypography,
        content     = content,
    )
}
