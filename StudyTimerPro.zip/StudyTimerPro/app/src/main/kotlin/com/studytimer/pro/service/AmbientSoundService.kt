package com.studytimer.pro.service

import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.IBinder
import com.studytimer.pro.R
import com.studytimer.pro.util.NotificationHelper
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Plays offline ambient loops only while a study session is running.
 * Controlled via Intents from TimerViewModel:
 *   ACTION_PLAY  – start / switch track  (EXTRA_TRACK = SoundTrack name)
 *   ACTION_STOP  – release MediaPlayer and stop service
 *   ACTION_VOL   – adjust volume (EXTRA_VOLUME = 0f..1f)
 *
 * Raw audio files must be placed in res/raw/:
 *   white_noise.mp3, rain.mp3, lofi.mp3, cafe.mp3, forest.mp3
 */
@AndroidEntryPoint
class AmbientSoundService : Service() {

    @Inject lateinit var notificationHelper: NotificationHelper

    companion object {
        const val ACTION_PLAY  = "com.studytimer.pro.AMBIENT_PLAY"
        const val ACTION_STOP  = "com.studytimer.pro.AMBIENT_STOP"
        const val ACTION_VOL   = "com.studytimer.pro.AMBIENT_VOL"
        const val EXTRA_TRACK  = "extra_track"
        const val EXTRA_VOLUME = "extra_volume"
    }

    enum class SoundTrack(val resId: Int, val label: String, val emoji: String) {
        WHITE_NOISE(R.raw.white_noise, "White Noise", "🌊"),
        RAIN       (R.raw.rain,        "Rain",        "🌧"),
        LOFI       (R.raw.lofi,        "Lo-Fi Beats", "🎵"),
        CAFE       (R.raw.cafe,        "Café",        "☕"),
        FOREST     (R.raw.forest,      "Forest",      "🌿"),
    }

    private var player: MediaPlayer? = null
    private var volume: Float = 0.5f

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> {
                val track = intent.getStringExtra(EXTRA_TRACK)
                    ?.let { runCatching { SoundTrack.valueOf(it) }.getOrNull() }
                    ?: SoundTrack.WHITE_NOISE
                volume = intent.getFloatExtra(EXTRA_VOLUME, volume)
                playTrack(track)
            }
            ACTION_STOP -> { releasePlayer(); stopSelf() }
            ACTION_VOL  -> {
                volume = intent.getFloatExtra(EXTRA_VOLUME, volume)
                player?.setVolume(volume, volume)
            }
        }
        return START_NOT_STICKY
    }

    private fun playTrack(track: SoundTrack) {
        releasePlayer()
        player = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            // setDataSource from raw resource
            val afd = resources.openRawResourceFd(track.resId)
            setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            isLooping = true
            setVolume(volume, volume)
            prepare()
            start()
        }
    }

    private fun releasePlayer() {
        player?.stop()
        player?.release()
        player = null
    }

    override fun onDestroy() { releasePlayer(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
