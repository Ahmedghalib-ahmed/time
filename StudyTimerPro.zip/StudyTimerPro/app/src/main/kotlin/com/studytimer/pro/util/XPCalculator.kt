package com.studytimer.pro.util

import kotlin.math.floor
import kotlin.math.sqrt

object XPCalculator {

    /**
     * Base: 1 XP per focus minute
     * Mode multiplier — Pomodoro rewards discipline, Countup is baseline.
     * Streak bonus — up to +50 % at 30+ day streak.
     */
    fun calculate(minutes: Int, timerMode: String, streak: Int): Int {
        val base = minutes.toFloat()
        val modeMultiplier = when (timerMode) {
            "POMODORO"  -> 1.5f
            "COUNTDOWN" -> 1.2f
            else        -> 1.0f     // COUNTUP
        }
        val streakBonus = (streak * 0.02f).coerceAtMost(0.5f)   // caps at 50 %
        return floor(base * modeMultiplier * (1f + streakBonus)).toInt()
    }

    /** Level formula: level = floor(sqrt(totalXP / 10)) + 1 */
    fun levelForXP(xp: Int): Int = floor(sqrt(xp / 10.0)).toInt() + 1

    /** XP required to reach a given level */
    fun xpForLevel(level: Int): Int = ((level - 1) * (level - 1)) * 10

    /** XP required to reach the next level */
    fun xpForNextLevel(level: Int): Int = xpForLevel(level + 1)

    /** Float 0..1 representing progress within the current level */
    fun progressInLevel(xp: Int): Float {
        val level    = levelForXP(xp)
        val start    = xpForLevel(level).toFloat()
        val end      = xpForNextLevel(level).toFloat()
        if (end <= start) return 1f
        return ((xp - start) / (end - start)).coerceIn(0f, 1f)
    }

    /** Human-readable level title */
    fun levelTitle(level: Int): String = when (level) {
        in 1..4   -> "Beginner"
        in 5..9   -> "Focused"
        in 10..14 -> "Dedicated"
        in 15..19 -> "Scholar"
        in 20..29 -> "Expert"
        in 30..39 -> "Master"
        in 40..49 -> "Grandmaster"
        else      -> "Legend"
    }
}
