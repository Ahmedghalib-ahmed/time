package com.studytimer.pro.ui.theme

import androidx.compose.ui.graphics.Color

// ── Brand ──────────────────────────────────────────────────────
val Purple       = Color(0xFF7C4DFF)
val PurpleLight  = Color(0xFF9E7BFF)
val PurpleDim    = Color(0xFF4A2E9A)
val PurpleGlow   = Color(0x407C4DFF)

// ── Background layers ──────────────────────────────────────────
val BgDeep       = Color(0xFF0D0E12)   // root background
val Surface1     = Color(0xFF161823)   // cards / bottom nav
val Surface2     = Color(0xFF1E2130)   // elevated cards
val Surface3     = Color(0xFF252840)   // input fields / chips

// ── Accent palette ─────────────────────────────────────────────
val Cyan         = Color(0xFF00D4FF)
val CyanDim      = Color(0x3300D4FF)
val Amber        = Color(0xFFFFB830)
val AmberDim     = Color(0x33FFB830)
val Green        = Color(0xFF00E676)
val GreenDim     = Color(0x3300E676)
val Red          = Color(0xFFFF5252)
val RedDim       = Color(0x33FF5252)
val Pink         = Color(0xFFFF4081)

// ── Subject colour tokens ──────────────────────────────────────
val SubjectColors = listOf(
    Color(0xFF7C4DFF), // purple
    Color(0xFF00BCD4), // teal
    Color(0xFFFF7043), // orange
    Color(0xFF4CAF50), // green
    Color(0xFFE91E63), // pink
    Color(0xFFFFEB3B), // yellow
    Color(0xFF2196F3), // blue
    Color(0xFF9C27B0), // violet
)

// ── Text ───────────────────────────────────────────────────────
val TextPrimary   = Color(0xFFF0F2FF)
val TextSecondary = Color(0xFF8A8FA8)
val TextDisabled  = Color(0xFF4A4E62)

// ── Divider / border ───────────────────────────────────────────
val BorderSubtle  = Color(0xFF1F2235)
val BorderBright  = Color(0xFF2E3250)
