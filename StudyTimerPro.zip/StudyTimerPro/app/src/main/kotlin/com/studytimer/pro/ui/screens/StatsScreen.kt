package com.studytimer.pro.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.studytimer.pro.data.local.entities.Achievements
import com.studytimer.pro.ui.components.MiniProgressRing
import com.studytimer.pro.ui.theme.*
import com.studytimer.pro.util.XPCalculator
import com.studytimer.pro.viewmodel.DayBar
import com.studytimer.pro.viewmodel.StatsViewModel

@Composable
fun StatsScreen(viewModel: StatsViewModel = hiltViewModel()) {
    val ui by viewModel.ui.collectAsState()
    val profile = ui.profile

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDeep)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(52.dp))
        Text("Stats & Progress", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(4.dp))
        Text("Your focus journey at a glance", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(24.dp))

        // ── XP / Level card ──────────────────────────────────────
        profile?.let { p ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape    = RoundedCornerShape(22.dp),
                colors   = CardDefaults.cardColors(containerColor = Color.Transparent),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(listOf(PurpleDim, Color(0xFF1A1040))),
                            RoundedCornerShape(22.dp),
                        )
                        .border(1.dp, Purple.copy(.4f), RoundedCornerShape(22.dp))
                        .padding(22.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Ring
                        Box(contentAlignment = Alignment.Center) {
                            MiniProgressRing(
                                progress   = ui.levelProgress,
                                size       = 76.dp,
                                stroke     = 7.dp,
                                color      = Amber,
                                trackColor = Surface3,
                            )
                            Text("${p.level}", fontSize = 22.sp,
                                fontWeight = FontWeight.Black, color = Amber)
                        }
                        Spacer(Modifier.width(18.dp))
                        Column {
                            Text(XPCalculator.levelTitle(p.level),
                                style = MaterialTheme.typography.titleLarge)
                            Text("Level ${p.level}",
                                style = MaterialTheme.typography.bodySmall, color = Amber)
                            Spacer(Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress        = { ui.levelProgress },
                                modifier        = Modifier.fillMaxWidth().height(6.dp)
                                    .clip(RoundedCornerShape(50)),
                                color           = Amber,
                                trackColor      = Surface3,
                            )
                            Spacer(Modifier.height(4.dp))
                            Text("${p.totalXP} XP  ·  ${XPCalculator.xpForNextLevel(p.level) - p.totalXP} to next",
                                style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        // ── Focus Score ──────────────────────────────────────────
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatBigCard("Focus Score", "${ui.focusScore}", "/100",
                color = scoreColor(ui.focusScore), modifier = Modifier.weight(1f))
            StatBigCard("This Week", "${ui.totalThisWeek} min", "",
                color = Cyan, modifier = Modifier.weight(1f))
            StatBigCard("This Month", "${ui.totalThisMonth} min", "",
                color = Green, modifier = Modifier.weight(1f))
        }

        Spacer(Modifier.height(24.dp))

        // ── 7-Day bar chart ──────────────────────────────────────
        Text("Last 7 Days", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(12.dp))
        BarChart(bars = ui.last7Bars, goalMins = profile?.dailyGoalMinutes ?: 120)

        Spacer(Modifier.height(24.dp))

        // ── Streak stats ─────────────────────────────────────────
        profile?.let { p ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StreakCard("🔥 Current", "${p.currentStreak} days", Amber, Modifier.weight(1f))
                StreakCard("🏆 Longest", "${p.longestStreak} days", Purple, Modifier.weight(1f))
                StreakCard("⏱ Total", "${p.totalFocusMinutes / 60}h ${p.totalFocusMinutes % 60}m",
                    Cyan, Modifier.weight(1f))
            }
        }

        Spacer(Modifier.height(24.dp))

        // ── Top subjects ─────────────────────────────────────────
        if (ui.topSubjects.isNotEmpty()) {
            Text("Top Subjects", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(12.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape    = RoundedCornerShape(18.dp),
                colors   = CardDefaults.cardColors(containerColor = Surface1),
                border   = BorderStroke(1.dp, BorderSubtle),
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    val maxMins = ui.topSubjects.maxOfOrNull { it.totalMinutes }?.coerceAtLeast(1) ?: 1
                    ui.topSubjects.forEach { sub ->
                        val frac = sub.totalMinutes.toFloat() / maxMins
                        val color = Color(android.graphics.Color.parseColor(sub.colorHex))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(sub.emoji, fontSize = 18.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Row(Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(sub.name, style = MaterialTheme.typography.labelLarge)
                                    Text("${sub.totalMinutes}m",
                                        style = MaterialTheme.typography.labelSmall, color = color)
                                }
                                Spacer(Modifier.height(4.dp))
                                LinearProgressIndicator(
                                    progress   = { frac },
                                    modifier   = Modifier.fillMaxWidth().height(5.dp)
                                        .clip(RoundedCornerShape(50)),
                                    color      = color,
                                    trackColor = Surface3,
                                )
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }

        // ── Achievements grid ────────────────────────────────────
        Text("Achievements", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(
            columns          = GridCells.Fixed(3),
            modifier         = Modifier.fillMaxWidth().heightIn(max = 600.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement   = Arrangement.spacedBy(10.dp),
            userScrollEnabled = false,
        ) {
            items(Achievements.all) { ach ->
                val unlocked = ach.id in ui.achievementIds
                AchievementBadge(
                    emoji    = ach.emoji,
                    title    = ach.title,
                    xp       = ach.xpReward,
                    unlocked = unlocked,
                )
            }
        }

        Spacer(Modifier.height(120.dp))
    }
}

// ── Sub-components ────────────────────────────────────────────

@Composable
private fun StatBigCard(
    label: String, value: String, suffix: String,
    color: Color, modifier: Modifier,
) {
    Card(
        modifier = modifier,
        shape    = RoundedCornerShape(16.dp),
        colors   = CardDefaults.cardColors(containerColor = Surface1),
        border   = BorderStroke(1.dp, BorderSubtle),
    ) {
        Column(
            Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center)
            Spacer(Modifier.height(6.dp))
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Black, color = color,
                textAlign = TextAlign.Center)
            if (suffix.isNotEmpty()) Text(suffix,
                style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }
    }
}

@Composable
private fun StreakCard(label: String, value: String, color: Color, modifier: Modifier) {
    Card(
        modifier = modifier,
        shape    = RoundedCornerShape(16.dp),
        colors   = CardDefaults.cardColors(containerColor = color.copy(.08f)),
        border   = BorderStroke(1.dp, color.copy(.3f)),
    ) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center,
                color = color)
            Spacer(Modifier.height(4.dp))
            Text(value, fontWeight = FontWeight.Bold, fontSize = 16.sp,
                textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun BarChart(bars: List<DayBar>, goalMins: Int) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(18.dp),
        colors   = CardDefaults.cardColors(containerColor = Surface1),
        border   = BorderStroke(1.dp, BorderSubtle),
    ) {
        Column(Modifier.padding(16.dp)) {
            val maxMins = maxOf(bars.maxOfOrNull { it.minutes } ?: 0, goalMins)
            val goalFrac = goalMins.toFloat() / maxMins

            Row(
                modifier              = Modifier.fillMaxWidth().height(160.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment     = Alignment.Bottom,
            ) {
                bars.forEach { bar ->
                    val frac = if (maxMins > 0) bar.minutes.toFloat() / maxMins else 0f
                    val hitGoal = bar.minutes >= goalMins
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Bottom,
                        modifier            = Modifier.weight(1f).fillMaxHeight(),
                    ) {
                        if (bar.minutes > 0) {
                            Text("${bar.minutes}m", style = MaterialTheme.typography.labelSmall,
                                color = if (hitGoal) Green else Purple)
                        }
                        Spacer(Modifier.height(2.dp))
                        Box(
                            modifier = Modifier
                                .width(28.dp)
                                .fillMaxHeight(frac.coerceAtLeast(0.02f))
                                .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                                .background(
                                    if (hitGoal)
                                        Brush.verticalGradient(listOf(Green, Green.copy(.5f)))
                                    else
                                        Brush.verticalGradient(listOf(Purple, PurpleDim))
                                )
                        )
                    }
                }
            }

            Spacer(Modifier.height(6.dp))
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                bars.forEach { bar ->
                    Text(bar.label, style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                }
            }

            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).background(Purple, CircleShape))
                Spacer(Modifier.width(6.dp))
                Text("Focus", style = MaterialTheme.typography.labelSmall)
                Spacer(Modifier.width(16.dp))
                Box(Modifier.size(8.dp).background(Green, CircleShape))
                Spacer(Modifier.width(6.dp))
                Text("Goal achieved (${goalMins}m)", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun AchievementBadge(emoji: String, title: String, xp: Int, unlocked: Boolean) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(if (unlocked) 1f else .4f),
        shape    = RoundedCornerShape(16.dp),
        colors   = CardDefaults.cardColors(
            containerColor = if (unlocked) Amber.copy(.1f) else Surface2),
        border   = BorderStroke(1.dp, if (unlocked) Amber.copy(.5f) else BorderSubtle),
    ) {
        Column(
            Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            if (unlocked) {
                Text(emoji, fontSize = 28.sp)
            } else {
                Icon(Icons.Default.Lock, null, tint = TextDisabled,
                    modifier = Modifier.size(28.dp))
            }
            Text(title, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center,
                maxLines = 2)
            if (unlocked) Text("+$xp XP", style = MaterialTheme.typography.labelSmall,
                color = Amber)
        }
    }
}

private fun scoreColor(score: Int) = when {
    score >= 80 -> Green
    score >= 50 -> Amber
    else        -> Red
}
