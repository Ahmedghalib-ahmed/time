package com.studytimer.pro.service

import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationManagerCompat
import com.studytimer.pro.util.NotificationHelper
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import javax.inject.Inject

/**
 * Keeps the timer ticking even when the screen is off.
 * The TimerViewModel controls this service via Intents:
 *   ACTION_START  – begin countdown (extras: EXTRA_SECONDS, EXTRA_MODE, EXTRA_SUBJECT)
 *   ACTION_TICK   – internal 1-second tick broadcast back to ViewModel via LocalBroadcast
 *   ACTION_STOP   – stop and remove foreground notification
 */
@AndroidEntryPoint
class TimerService : Service() {

    @Inject lateinit var notificationHelper: NotificationHelper

    companion object {
        const val ACTION_START   = "com.studytimer.pro.START"
        const val ACTION_STOP    = "com.studytimer.pro.STOP"
        const val ACTION_TICK    = "com.studytimer.pro.TICK"
        const val EXTRA_SECONDS  = "extra_seconds"
        const val EXTRA_MODE     = "extra_mode"
        const val EXTRA_SUBJECT  = "extra_subject"
        const val EXTRA_REMAINING = "extra_remaining"
    }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var tickJob: Job? = null
    private var remaining = 0
    private var mode = "COUNTDOWN"
    private var subjectName: String? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                remaining   = intent.getIntExtra(EXTRA_SECONDS, 0)
                mode        = intent.getStringExtra(EXTRA_MODE) ?: "COUNTDOWN"
                subjectName = intent.getStringExtra(EXTRA_SUBJECT)
                startForegroundNotification()
                startTicking()
            }
            ACTION_STOP -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startForegroundNotification() {
        val notif = notificationHelper.buildTimerNotification(
            timeLabel   = formatTime(remaining),
            mode        = mode,
            subjectName = subjectName,
        )
        startForeground(NotificationHelper.NOTIF_TIMER_ID, notif)
    }

    private fun startTicking() {
        tickJob?.cancel()
        tickJob = scope.launch {
            while (remaining > 0) {
                delay(1_000)
                remaining--
                // Broadcast tick back to ViewModel
                sendBroadcast(Intent(ACTION_TICK).apply {
                    putExtra(EXTRA_REMAINING, remaining)
                })
                // Refresh notification every 5 s to avoid binder spam
                if (remaining % 5 == 0) {
                    NotificationManagerCompat.from(this@TimerService).notify(
                        NotificationHelper.NOTIF_TIMER_ID,
                        notificationHelper.buildTimerNotification(
                            timeLabel   = formatTime(remaining),
                            mode        = mode,
                            subjectName = subjectName,
                        )
                    )
                }
            }
            // Session finished
            sendBroadcast(Intent(ACTION_TICK).apply { putExtra(EXTRA_REMAINING, 0) })
            stopSelf()
        }
    }

    private fun formatTime(secs: Int) =
        "${(secs / 60).toString().padStart(2, '0')}:${(secs % 60).toString().padStart(2, '0')}"

    override fun onDestroy() {
        tickJob?.cancel()
        scope.cancel()
        notificationHelper.cancelTimer()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
